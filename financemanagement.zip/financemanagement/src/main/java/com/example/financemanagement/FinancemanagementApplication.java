package com.example.financemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinancemanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinancemanagementApplication.class, args);
	}

}
